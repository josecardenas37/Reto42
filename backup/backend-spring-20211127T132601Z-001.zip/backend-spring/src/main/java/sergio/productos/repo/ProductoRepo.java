package sergio.productos.repo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import sergio.productos.modelo.Producto;

public interface ProductoRepo extends MongoRepository<Producto, String>{
	List<Producto> findByCategoria(String categoria);
	List<Producto> findByNombre(String nombre);
	
}
