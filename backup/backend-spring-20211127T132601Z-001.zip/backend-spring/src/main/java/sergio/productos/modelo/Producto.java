package sergio.productos.modelo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document
public class Producto {
	
	@Id
	private String id;
	
	private String nombre;
	private String categoria;
	private String disponibilidad;
	private String precio;
	private String stock;
	
	public Producto() {	
		
	}
	
	public Producto(String id, String nombre, String categoria, String disponibilidad, String precio, String stock) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.categoria = categoria;
		this.disponibilidad = disponibilidad;
		this.precio = precio;
		this.stock = stock;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getDisponibilidad() {
		return disponibilidad;
	}
	public void setDisponibilidad(String disponibilidad) {
		this.disponibilidad = disponibilidad;
	}
	public String getPrecio() {
		return precio;
	}
	public void setPrecio(String precio) {
		this.precio = precio;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
}
