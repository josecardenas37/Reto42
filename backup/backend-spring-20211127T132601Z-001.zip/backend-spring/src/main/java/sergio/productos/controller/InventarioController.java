package sergio.productos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import sergio.productos.modelo.Inventario;
import sergio.productos.repo.InventarioRepo;

@CrossOrigin
@RestController
@RequestMapping("/inventario")
public class InventarioController {
	
	@Autowired
	private InventarioRepo inventariorepo;
	
	@GetMapping("")
	List<Inventario> productos() {
		return inventariorepo.findAll();
	}
	
	@ResponseStatus(HttpStatus.CREATED)
	@PostMapping("/new")
	Inventario crearProducto(@RequestBody Inventario inventario) {
		return inventariorepo.save(inventario);
	}
}
