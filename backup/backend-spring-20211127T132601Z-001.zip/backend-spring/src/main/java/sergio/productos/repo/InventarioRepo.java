package sergio.productos.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import sergio.productos.modelo.Inventario;

public interface InventarioRepo extends MongoRepository<Inventario, String>{

}
