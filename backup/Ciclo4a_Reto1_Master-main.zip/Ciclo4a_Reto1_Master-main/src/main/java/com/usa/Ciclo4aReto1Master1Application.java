package com.usa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ciclo4aReto1Master1Application {

    public static void main(String[] args) {
        SpringApplication.run(Ciclo4aReto1Master1Application.class, args);
    }

}
