package com.usa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ciclo4aReto1Master1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
